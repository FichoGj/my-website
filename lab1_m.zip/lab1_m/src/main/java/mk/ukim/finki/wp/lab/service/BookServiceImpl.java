package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    BookRepository bookRepository;
    @Autowired
    AuthorRepository authorRepository;

    @Override
    public List<Book> listAll() {
        return bookRepository.findAll();
    }


public Book findById(long id){
        return bookRepository.findById(id);
}

    @Override
    public Book save(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public void deleteById(long id) {
        Book book = bookRepository.findById(id);
        if(book != null){
            bookRepository.findAll().removeIf(b -> b.getId() == id);
        }
    }

    public Book save(String title, String genre, Double averageRating, Author author) {
        Book book = new Book(title, genre, averageRating, author);
        return bookRepository.save(book);
    }
}

