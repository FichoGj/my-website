package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
//?
@Component
public class DataHolder {

    public static List<Book> books = new ArrayList<Book>();
    public static List<BookReservation> reservations = new ArrayList<>();

    @PostConstruct
    public void init(){
        Author author1 = new Author("J.K.", "Rowling", "United Kingdom", "Author of the Harry Potter series.");
        Author author2 = new Author("George", "Orwell", "United Kingdom", "Author of 1984 and Animal Farm.");
        Author author3 = new Author("Gabriel", "Garcia Marquez", "Colombia", "Famous for One Hundred Years of Solitude.");
        Author author4 = new Author("Haruki", "Murakami", "Japan", "Japanese author known for Kafka on the Shore.");

        books.add(new Book("Pride and Prejudice","Classic Novel",8,author1));
        books.add(new Book("Meditations","Science & Philosophy",7,author2));
        books.add(new Book("And Then There Were None","Thriller",10,author3));
    }

}
