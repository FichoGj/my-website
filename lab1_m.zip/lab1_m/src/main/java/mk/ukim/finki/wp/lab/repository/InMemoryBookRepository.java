package mk.ukim.finki.wp.lab.repository;


import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.Book;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class InMemoryBookRepository implements BookRepository {
    @Override
    public List<Book> findAll() {
        return DataHolder.books;
    }

    @Override
    public List<Book> searchBooks(String text, Double rating) {
        return DataHolder.books.stream().filter(b -> b.getTitle().toLowerCase().contains(text)).filter(b->b.getAverageRating() >=rating).toList();
    }

    @Override
    public Book save(Book book) {
        DataHolder.books.removeIf(b -> b.getTitle().equals(book.getTitle()));
        DataHolder.books.add(book);
        return book;
    }

    @Override
    public Book findById(long id){
        return DataHolder.books.stream().filter(b->b.getId()==id).findFirst().orElse(null);
    }


}
