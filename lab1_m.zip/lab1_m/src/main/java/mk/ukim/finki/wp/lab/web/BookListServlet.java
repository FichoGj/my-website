package mk.ukim.finki.wp.lab.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.service.BookService;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(urlPatterns = "/books")
public class BookListServlet extends HttpServlet {

    private final BookService bookService;
    private final SpringTemplateEngine templateEngine;

    public BookListServlet(BookService bookService, SpringTemplateEngine templateEngine) {
        this.bookService = bookService;
        this.templateEngine = templateEngine;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        String titleFilter = req.getParameter("titleFilter");
        String minRatingParam = req.getParameter("minRating");
        double minRating = 0;

        if (minRatingParam != null && !minRatingParam.isEmpty()) {
            minRating = Double.parseDouble(minRatingParam);

        }

        List<Book> books = bookService.listAll();

        if ((titleFilter != null && !titleFilter.isEmpty()) || (minRatingParam != null && !minRatingParam.isEmpty())) {
            double finalMinRating = minRating;
            books = books.stream().filter(b -> titleFilter == null || titleFilter.isEmpty() || b.getTitle().toLowerCase().contains(titleFilter.toLowerCase())).filter(b -> minRatingParam == null || minRatingParam.isEmpty() || b.getAverageRating() >= finalMinRating).toList();
        }

        IWebExchange webExchange = JakartaServletWebApplication.buildApplication(getServletContext()).buildExchange(req, resp);

        WebContext context = new WebContext(webExchange);
        context.setVariable("books", books);
        context.setVariable("titleFilter", titleFilter != null ? titleFilter : "");
        context.setVariable("minRating", minRating);

        templateEngine.process("listBook.html", context, out);
    }
}
