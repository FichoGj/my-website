package mk.ukim.finki.wp.lab.model;

public class Author {

    private static long counter = 0;
    private Long id;
    private String name;
    private String surname;
    private String country;
    private String biography;


    public Author(String name, String surname, String country, String biography) {
        this.name = name;
        this.surname = surname;
        this.country = country;
        this.biography = biography;
        this.id = counter++;
    }

    public Author(String authorName, String authorSurname) {
        this.name = authorName;
        this.surname = authorSurname;
    }

    public String getName() {
        return name;
    }

    public Long getId() {
        return id;
    }

    public String getSurname() {
        return surname;
    }

    public String getCountry() {
        return country;
    }

    public String getBiography() {
        return biography;
    }

    public void setName(String authorName) {
        this.name = authorName;
    }

    public void setSurname(String authorSurname) {
    this.surname = authorSurname;
    }
}
