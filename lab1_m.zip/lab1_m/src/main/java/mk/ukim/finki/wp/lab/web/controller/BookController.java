package mk.ukim.finki.wp.lab.web.controller;


import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.service.AuthorService;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class BookController {

    @Autowired
    private  BookService bookService;
    @Autowired
    private  AuthorService authorService;



    //ovoj metod ke se povika koga ke se otvori .../books
    @GetMapping("/books")
public String getBooksPage(@RequestParam(required = false) String error, Model model){

        if(error != null){
            model.addAttribute("errorMessage", error);
        }

        List<Book> books = bookService.listAll();
        model.addAttribute("books", books);

    return "listBook";
}


@GetMapping("/books/add")
public String showAddBookForm(Model model){

        model.addAttribute("book", new Book());
        model.addAttribute("authors",authorService.findAll());

        return "addBook";
}





    @PostMapping("/books/add")
    public String saveBook(@RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam String authorName,
                           @RequestParam String authorSurname) {

        Author author = new Author(authorName,authorSurname);
        author.setName(authorName);
        author.setSurname(authorSurname);
        bookService.save(title, genre, averageRating, author);

        return "redirect:/books";
    }


    @GetMapping("/books/edit/{bookId}")
    public String showEditBookForm(@PathVariable Long bookId, Model model){


        Book book = bookService.findById(bookId);
        if (book == null){
            return "redirect:books?error=bookNotFound";
        }

        model.addAttribute("book", book);
        model.addAttribute("authors",authorService.findAll());

        return "editBook";
    }


    @PostMapping("/books/edit/{bookId}")
    public String editBook(@PathVariable Long bookId,
                           @RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId){


        Book book = bookService.findById(bookId);
        Author author = authorService.findById(authorId);

        if (book == null || author == null){
            return "redirect:books?error=bookNotFound";
        }

        book.setTitle(title);
        book.setGenre(genre);
        book.setAverageRating(averageRating);
        book.setAuthor(author);

        bookService.save(book);
        return "redirect:/books";
    }

    @GetMapping("/books/delete/{bookId}")
    public String delete(@PathVariable Long bookId){

        Book book = bookService.findById(bookId);

        if (book == null){
            return "redirect:books?error=bookNotFound";
        }

bookService.deleteById(bookId);
        return "redirect:/books";
    }







}
