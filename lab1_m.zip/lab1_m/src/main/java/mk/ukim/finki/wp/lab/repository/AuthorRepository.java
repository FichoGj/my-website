package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.Author;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class AuthorRepository {

    List<Author> authors;

    public AuthorRepository() {
        authors = new ArrayList<Author>();
        authors.add(new Author("J.K.", "Rowling", "United Kingdom", "Author of the Harry Potter series."));
        authors.add(new Author("George", "Orwell", "United Kingdom", "Author of 1984 and Animal Farm."));
        authors.add(new Author("Gabriel", "Garcia Marquez", "Colombia", "Famous for One Hundred Years of Solitude."));
    }


    public List<Author> findAll() {
        return authors;
    }


     public Author findAuthorById(Long id){
        return findAll().stream().filter(author ->author.getId().equals(id)).findFirst().orElse(null);
    }

}
