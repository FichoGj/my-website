package mk.ukim.finki.wp.kol2025g2.model;

public enum SlopeDifficulty {
    GREEN,
    BLUE,
    RED,
    BLACK
}
