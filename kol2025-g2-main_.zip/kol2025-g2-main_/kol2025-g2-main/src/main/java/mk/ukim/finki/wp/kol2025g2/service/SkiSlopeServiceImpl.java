package mk.ukim.finki.wp.kol2025g2.service;

import mk.ukim.finki.wp.kol2025g2.model.SkiSlope;
import mk.ukim.finki.wp.kol2025g2.model.SlopeDifficulty;
import mk.ukim.finki.wp.kol2025g2.repository.SkiResortRepository;
import mk.ukim.finki.wp.kol2025g2.repository.SkiSlopeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SkiSlopeServiceImpl implements SkiSlopeService {

    private final SkiSlopeRepository skiSlopeRepository;
    private final SkiResortRepository skiResortRepository;

    @Autowired
    public SkiSlopeServiceImpl(SkiSlopeRepository skiSlopeRepository, SkiResortRepository skiResortRepository) {
        this.skiSlopeRepository = skiSlopeRepository;
        this.skiResortRepository = skiResortRepository;
    }


    @Override
    public List<SkiSlope> listAll() {
        return skiSlopeRepository.findAll();
    }

    @Override
    public SkiSlope findById(Long id) {
        return null;
    }


    @Override
    public SkiSlope create(String name, Integer length, SlopeDifficulty difficulty, Long skiResort) {
        var resort = skiResortRepository.findById(skiResort)
                .orElseThrow(() -> new RuntimeException("Ski resort not found"));
        SkiSlope slope = new SkiSlope();
        slope.setName(name);
        slope.setLength(length);
        slope.setDifficulty(difficulty);
        slope.setSkiResort(resort);
        slope.setClosed(false);
        return skiSlopeRepository.save(slope); // ова е JPA create/save
    }


    @Override
    public SkiSlope update(Long id, String name, Integer length, SlopeDifficulty difficulty, Long skiResort) {
        SkiSlope slope = skiSlopeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ski slope not found"));

        var resort = skiResortRepository.findById(skiResort)
                .orElseThrow(() -> new RuntimeException("Ski resort not found"));

        slope.setName(name);
        slope.setLength(length);
        slope.setDifficulty(difficulty);
        slope.setSkiResort(resort);

        return skiSlopeRepository.save(slope);
    }

    @Override
    public SkiSlope delete(Long id) {
        return null;
    }

    @Override
    public SkiSlope close(Long id) {
        return null;
    }

    @Override
    public Page<SkiSlope> findPage(String name, Integer length, SlopeDifficulty difficulty, Long skiResort, int pageNum, int pageSize) {
return null;
    }
}
