package mk.ukim.finki.wp.kol2025g2.service;

import mk.ukim.finki.wp.kol2025g2.model.SkiResort;
import mk.ukim.finki.wp.kol2025g2.repository.SkiResortRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SkiResortServiceImpl implements SkiResortService {

    private final SkiResortRepository skiResortRepository;

    @Autowired
    public SkiResortServiceImpl(SkiResortRepository skiResortRepository) {
        this.skiResortRepository = skiResortRepository;
    }

    @Override
    public SkiResort findById(Long id) {
        return null;
    }

    @Override
    public SkiResort create(String name, String location) {
        SkiResort resort = new SkiResort(name, location);
        return skiResortRepository.save(resort);
    }

    @Override
    public List<SkiResort> listAll() {
        return skiResortRepository.findAll();
    }
}
