package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
//?
@Component
public class DataHolder {

    public static List<Book> books = new ArrayList<Book>();
    public static List<BookReservation> reservations = new ArrayList<>();

    @PostConstruct
    public void init(){
        books.add(new Book("Pride and Prejudice","Classic Novel",8));
        books.add(new Book("Meditations","Science & Philosophy",7));
        books.add(new Book("And Then There Were None","Thriller",10));
    }

}
