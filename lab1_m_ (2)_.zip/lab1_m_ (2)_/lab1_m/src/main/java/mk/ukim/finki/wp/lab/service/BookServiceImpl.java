package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;

    private List<Book> books = new ArrayList<>();

    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public List<Book> listAll() {
        return bookRepository.findAll();
    }

    @Override
    public Book findById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }


    @Override
    public Book save(Book book) {
//        Book book = new Book(title, genre, averageRating, author);
        return bookRepository.save(book);
    }


    @Override
    public List<Book> findAllByAuthor(Long authorId) {
        return bookRepository.findAllByAuthor_Id(authorId);
    }

    @Override
    public void deleteById(Long id) {
        bookRepository.deleteById(id);
    }
    @Override
    public List<Book> searchByAuthorName(String name) {
        return bookRepository.findAll()
                .stream()
                .filter(book -> (book.getAuthor().getName() + " " + book.getAuthor().getSurname())
                        .toLowerCase()
                        .contains(name.toLowerCase()))
                .toList();
    }



}
