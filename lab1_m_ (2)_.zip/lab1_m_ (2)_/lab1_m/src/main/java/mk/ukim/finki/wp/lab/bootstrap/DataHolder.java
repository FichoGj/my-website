package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import org.springframework.stereotype.Component;

@Component
public class DataHolder {

    private final AuthorRepository authorRepository;


    public DataHolder(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    @PostConstruct
    public void init() {
        if (authorRepository.count() == 0) {
            authorRepository.save(new Author("Filip", "Gjorgievski"));
            authorRepository.save(new Author("Marko", "Markovski"));
            authorRepository.save(new Author("Ana", "Anevska"));
        }
    }
}
