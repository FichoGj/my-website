package mk.ukim.finki.wp.lab.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.service.AuthorService;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BookController {

    private final BookService bookService;
    private final AuthorService authorService;

    public BookController(BookService bookService, AuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }

    @GetMapping("/books")
    public String getBooksPage(
            @RequestParam(required = false) String error,
            @RequestParam(required = false) String authorName,
            Model model) {

        List<Book> books;

        if (authorName != null && !authorName.isEmpty()) {
            books = bookService.searchByAuthorName(authorName);  // ВАЖНО!!!
            model.addAttribute("authorName", authorName);
        } else {
            books = bookService.listAll();
        }

        model.addAttribute("books", books);
        return "listBook";
    }


    // ADD FORM
    @GetMapping("/books/add")
    public String showAddBookForm(Model model) {

        model.addAttribute("book", new Book());
        model.addAttribute("authors", authorService.listAll());

        return "addBook";
    }

    // ADD SUBMIT
    @PostMapping("/books/add")
    public String saveBook(@RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId) {

        Author author = authorService.findById(authorId);
        Book book = new Book(title, genre, averageRating, author);
        bookService.save(book);

        return "redirect:/books";
    }

    // EDIT FORM
    @GetMapping("/books/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {

        Book book = bookService.findById(id);
        if (book == null) return "redirect:/books?error=BookNotFound";

        model.addAttribute("book", book);
        model.addAttribute("authors", authorService.listAll());

        return "editBook";
    }

    // EDIT SUBMIT
    @PostMapping("/books/edit/{id}")
    public String editBook(@PathVariable Long id,
                           @RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId) {

        Book book = bookService.findById(id);
        Author author = authorService.findById(authorId);

        if (book == null || author == null)
            return "redirect:/books?error=BookNotFound";

        // UPDATE fields
        book.setTitle(title);
        book.setGenre(genre);
        book.setAverageRating(averageRating);
        book.setAuthor(author);

        // SAVE updated book (NOT creating a new one)
        bookService.save(book);
        return "redirect:/books";
    }

    // DELETE
    @GetMapping("/books/delete/{id}")
    public String deleteBook(@PathVariable Long id) {

        bookService.deleteById(id);
        return "redirect:/books";
    }

    @GetMapping("/books/reservation")
    public String showReservationForm() {
        return "reservation";  // ова HTML-то што го прати
    }
    @PostMapping("/books/reservation")
    public String showReservation(
            @RequestParam String readerName,
            @RequestParam String bookTitle,
            @RequestParam int numberOfCopies,
            HttpServletRequest request,
            Model model) {

        String clientIp = request.getRemoteAddr();

        model.addAttribute("readerName", readerName);
        model.addAttribute("bookTitle", bookTitle);
        model.addAttribute("numberOfCopies", numberOfCopies);
        model.addAttribute("clientIp", clientIp);

        return "reservationConfirmation";
    }







}
