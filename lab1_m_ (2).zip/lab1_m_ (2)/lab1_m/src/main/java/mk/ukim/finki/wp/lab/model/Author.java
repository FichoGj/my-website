package mk.ukim.finki.wp.lab.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Author {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String surname;
    private String country;
    private String biography;
    @OneToMany(mappedBy = "author")
    private List<Book> books = new ArrayList<Book>();

    public Author() {}

    public Author(String name, String surname, String country, String biography) {
        this.name = name;
        this.surname = surname;
        this.country = country;
        this.biography = biography;
    }

    public Author(String authorName, String authorSurname) {
        this.name = authorName;
        this.surname = authorSurname;
    }

    public String getName() {
        return name;
    }

    public Long getId() {
        return id;
    }

    public String getSurname() {
        return surname;
    }

    public String getCountry() {
        return country;
    }

    public String getBiography() {
        return biography;
    }

    public void setName(String authorName) {
        this.name = authorName;
    }

    public void setSurname(String authorSurname) {
    this.surname = authorSurname;
    }
}
