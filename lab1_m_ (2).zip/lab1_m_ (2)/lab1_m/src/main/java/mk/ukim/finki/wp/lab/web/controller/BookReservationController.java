//package mk.ukim.finki.wp.lab.web.controller;
//
//import jakarta.servlet.http.HttpServletRequest;
//import mk.ukim.finki.wp.lab.model.BookReservation;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//@Controller
//public class BookReservationController {
//
//    @GetMapping("/books/reservation")
//    public String reservation() {
//
//        return "reservation";
//    }
//
//    @PostMapping("/books/reservation")
//    public String showReservation(
//            @RequestParam String readerName,
//            @RequestParam String bookTitle,
//            @RequestParam int numberOfCopies,
//            HttpServletRequest request,
//            Model model) {
//
//        String clientIp = request.getRemoteAddr();
//
//        // креираме објект на BookReservation
//        BookReservation reservation = new BookReservation(readerName, bookTitle, (long) numberOfCopies);
//
//        model.addAttribute("reservation", reservation);
//        model.addAttribute("clientIp", clientIp);
//
//        return "reservationConfirmation";
//    }
//
//
//}
